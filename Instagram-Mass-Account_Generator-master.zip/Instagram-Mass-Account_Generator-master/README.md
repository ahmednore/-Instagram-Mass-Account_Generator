# Instagram-Mass-Account_Generator

THIS IS FOR EDUCATIONAL PURPOSES ONLY!

Instagram mass account creator with fake Emails.

Hey guys, so this is an Bot created with selenium for mass-producing instagram account. The account then can be used for following an individual (Still working on that projects.)

pip install selenium

pip install http-request-randomizer

*WORK TO BE DONE*

1) Check if proxy is working before rediricting to instagram (Done!)

*NEXT PROJECTS*

1) Like and followers bots using the username.txt
